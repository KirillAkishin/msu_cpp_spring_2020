#include <sstream>
#include <fstream>
#include <string>
#include <vector>

int handler(std::string& line);
int counter(std::ifstream& infile);